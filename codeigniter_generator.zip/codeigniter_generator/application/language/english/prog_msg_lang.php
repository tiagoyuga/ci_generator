<?php
// ".$this->ci->lang->line('model_busca_todos')."
$lang['model_busca_todos']="find_all";
$lang['model_busca_um_array']="find_by_array";
$lang['model_busca_um']="find_one";
$lang['model_excluir']="excluir";
$lang['model_cadastrar']="insert";
$lang['controller_listar']="list";
