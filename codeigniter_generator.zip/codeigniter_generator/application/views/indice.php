<?php 

$this->load->view('conecta');

?>