<?php

$lang['model_busca_todos']="busca_todos";
$lang['model_busca_um_array']="busca_por_array";
$lang['model_busca_um']="busca_um";
$lang['model_excluir']="excluir";
$lang['controller_listar']="listar";
$lang['model_cadastrar']="insert";
//$lang['controller_listar']="listar";