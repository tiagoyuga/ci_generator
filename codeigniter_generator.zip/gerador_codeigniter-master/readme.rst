Este projeto é feito em codeigniter 3.x e é um gerador de codigo base para o mesmo.
Utilizando o sgbd como base dos dados.
Ele gera diversos dados:
Escreve uma controller
escreve uma model
gera forumalario de visualização
gera formalario de edição

ele cria a view e o edit para a modal dos dados basica já com alguns tipos de dados.

O código também é iniciado para criar o auto_complete  para o netbeans.


